<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "onlineshop";


// Create connection
$con = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$con) {
    echo "<script>ALERT('cant be connected');</script>";
}


?>
